<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/12/3
 * Time: 15:36
 */
include ('PHPExcel.php') ;
//include 'PHPExcel/PHPExcel/IOFactory.php';
$objPHPExcel=new PHPExcel();

$data=array(
    0=>array('id'=>2013,'name'=>'张某某','age'=>21),
    1=>array('id'=>201,'name'=>'EVA','age'=>21)
);

$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1','编号');
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('B1','姓名');
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1','年龄');

foreach($data as $key => $value){
    $key+=2;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$key,$value['id']);
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$key,$value['name']);
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$key,$value['age']);
}

$objPHPExcel->getActiveSheet() -> setTitle('SetExcelName');
$objPHPExcel-> setActiveSheetIndex(0);

header("Content-Type: application/vnd.ms-excel;");
/*header("Content-Disposition:attachment;filename=5kcrm_user_".date('Y-m-d',mktime()).".xls");*/
header("Pragma:no-cache");
header("Expires:0");
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');