<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/12/3
 * Time: 17:49
 */
require_once 'reader.php';

// ExcelFile($filename, $encoding);

$data = new Spreadsheet_Excel_Reader();

// Set output Encoding.

$data->setOutputEncoding('gbk');

//”data.xls”是指要导入到mysql中的excel文件

$data->read('data.xls');

@ $db = mysql_connect('localhost', 'root', '123456') or

die("Could not connect to database.");//连接数据库

mysql_query("set names 'gbk'");//输出中文

mysql_select_db('mydb'); //选择数据库

error_reporting(E_ALL ^ E_NOTICE);

//for ($i = 1; $i <= $data->sheets[0]['numRows']; $i++) {

//以下注释的for循环打印excel表数据

/*

for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) {

echo """.$data->sheets[0]['cells'][$i][$j]."",";

}

echo "n";